############################ Global Mart Time Series Analysis #################################
# 1. Business Understanding
# 2. Data Understanding
# 3. Data Preparation
# 4. Model Building 
# 5 Conclusions

#####################################################################################

# 1. Business Understanding: 

# "Global Mart" is an online store super giant having worldwide operations. 
# It takes orders and delivers across the globe and deals with all the major product categories
# - consumer, corporate & home office.
# Now as a sales/operations manager, you want to finalise the plan for the next 6 months.  
# So, you want to forecast the sales and the demand for the next 6 months, 
# that would help you manage the revenue and inventory accordingly.
# The store caters to 7 different market segments and in 3 major categories. You want to forecast at this granular level, 
# so you subset your data into 21 (7*3) buckets before analysing these data.
# But not all of these 21 market buckets are important from the store's point of view. 
# So you need to find out 2 most profitable (and consistent) segment from these 
# 21 and forecast the sales and demand for these segments.

#####################################################################################

# 2. Data Understanding: 
# The data currently has the transaction level data, 
# where each row represents a particular order made on the online store. 
# There are 24 attributes related to each such transaction. The "Market" attribute has 
# 7-factor levels representing the geographical market sector that the customer belongs to. 
# The "Segment" attribute tells which of the 3 segments that customer belongs to. 
# Data has 51290 observations with 24 variables

#####################################################################################

#3. Data Preparation: 


#Loading Neccessary libraries

# *** Set working directory ***
#setwd("D:/PGDDM/Course 4/Case Study- Global Mart")
## Load required libraries

library(graphics)
library(forecast)
library(ggplot2)
library(data.table)
library(dplyr)
library(lubridate)
library(xts)

# Loading the datafile into R

global_superstore <- read.csv("Global Superstore.csv", header = T, sep = ',')

summary(global_superstore)
str(global_superstore)

# Correcting discrepancies in data format

global_superstore$Order.Date <- as.Date(global_superstore$Order.Date, "%d-%m-%Y")
global_superstore$Ship.Date <- as.Date(global_superstore$Ship.Date, "%d-%m-%Y")

# Duplicated rows

sum(duplicated(global_superstore)) # no duplicate rows

# Checking for NAs

sapply(global_superstore, function(y) sum(length(which(is.na(y)))))
#Only postal Code attribute has 41296 observations as NA

# Identifying to top 2 segments in terms of profit

mean(global_superstore$Profit)
levels(global_superstore$Segment) # 3 Segments:"Consumer" "Corporate" "Home Office"
levels(global_superstore$Market) # 7 Markets:"Africa" "APAC" "Canada" "EMEA" "EU" "LATAM" "US" 


global_superstore_sum <- global_superstore %>% 
  group_by(Market, Segment," Month&Year" = format(as.Date(global_superstore$Order.Date), "%Y-%m") ) %>% 
  summarise(MonthlyProfit = sum(Profit), MonthlySales = sum(Sales), MonthlyQuantity = sum(Quantity) ) %>% 
  mutate(TotalProfit = sum(MonthlyProfit), AverageProfit = mean(MonthlyProfit), 
         stddev = sd(MonthlyProfit) , COV = sd(MonthlyProfit)/mean(abs(MonthlyProfit))) 

#COV is least for Consumer EU and Consumer APAC segments 

#Top 2 segments by profit
global_superstore_tot <- global_superstore_sum %>%
  group_by(Market, Segment) %>% 
  summarise(AverageProfit = max(AverageProfit), TotalSales = max(MonthlySales), TotalQuantity = max(MonthlyQuantity) , ProfitCOV = max(COV))%>%
  arrange(desc(AverageProfit)  )
# #Market  Segment     AverageProfit TotalSales TotalQuantity ProfitCOV
# 1 APAC   Consumer            4642.     82286.          885.     0.632
# 2 EU     Consumer            3931.     68952.          932.     0.607

#Top 2 segments by Profit Coefficient of Variance:
global_superstore_tot%>%arrange((ProfitCOV))

# Market Segment     AverageProfit TotalSales TotalQuantity ProfitCOV
# 1 EU     Consumer            3931.     68952.          932.     0.607
# 2 APAC   Consumer            4642.     82286.          885.     0.632


#Plots to highlight the segments with Highest and Average Profits
ggplot(global_superstore_sum, aes(x = Market, y = TotalProfit, fill=Segment ))+ geom_bar(stat="identity",position="dodge")+xlab("Market")+ylab("Total Profit")+ggtitle("Total Profit") 

ggplot(global_superstore_sum, aes(x = Market, y = AverageProfit, fill=Segment ))+ geom_bar(stat="identity",position="dodge")+xlab("Market")+ylab("Average Profit")+ggtitle("Average Profit") 


#Plots to highlight the segments with least coefficient of variance
ggplot(global_superstore_sum, aes(x = Market, y = COV, fill=Segment ))+ geom_bar(stat="identity",position="dodge")+xlab("Market")+ylab("Coeff. of Variance of Profit")+ggtitle("Coeff. of Variance in Profit Vs. Market Segment") 


# Since the Average Profits is highest for EU - Consumer and APAC - Consumer segments, we will consider these two for our analysis

# Creating Subsets for the two chosen segments

myvars <- c("Market", "Segment", "Order.Date", "Sales", "Quantity", "Profit")
SS <- global_superstore[,myvars]

# conver the order date to CCYY-MM format so that we can group by the month.
SS$Order.Date <- format(as.Date(SS$Order.Date),format="%Y-%m-%d")

SS$order.YY.MM <- format(as.Date(SS$Order.Date),format="%Y-%m")

APAC_Consumer <- setDT(SS)[Market=="APAC" & Segment=="Consumer"]
EU_Consumer <- setDT(SS)[Market=="EU" & Segment=="Consumer"]

###################################################################################################################
# Let us now create TS for sales in APAC. 
APAC_DF_Sales <- aggregate(APAC_Consumer$Sales, by=list(Category=APAC_Consumer$order.YY.MM), FUN=sum)

# Add month number in the DF, which will be used for model prediction.
APAC_DF_Sales$Month <- seq.int(nrow(APAC_DF_Sales))
APAC_DF_Sales <- subset(APAC_DF_Sales,select=c(3,2))

colnames(APAC_DF_Sales) <- c("Month","Sales")

total_timeser <- ts(APAC_DF_Sales$Sales)
indata <- APAC_DF_Sales[1:42,]
timeser <- ts(indata[,2])

plot(timeser)


# Let's first decompose the time series with a freq of 12, to see its components.
ts1 <-ts(indata[,2], frequency = 12)
decomposedRes <- decompose(ts1, type="mult") 
plot (decomposedRes) # As seen from the plots, we have trend as well as seasonality.

#Smoothing the series - Moving Average Smoothing
detach("package:dplyr",unload = TRUE)
w <-2
smoothedseries <- filter(timeser, 
                         filter=rep(1/(2*w+1),(2*w+1)), 
                         method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

#Plot the smoothed time series

timevals_in <- indata$Month
lines(smoothedseries, col="blue", lwd=2)

#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit <- lm(Sales ~ sin(0.55*Month) * poly(Month,3) + cos(0.55*Month) * poly(Month,3)
            + Month, data=smootheddf)
global_pred <- predict(lmfit, Month=timevals_in)
summary(global_pred)
lines(timevals_in, global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred <- timeser-global_pred
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

#We'll check if the residual series is white noise

resi <- local_pred-fitted(armafit)
library(tseries)
adf.test(resi,alternative = "stationary")
kpss.test(resi)
# Both ADF and KPSS indicate that the residue is white noise. So we can stop here.

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months

outdata <- APAC_DF_Sales[43:48,]
timevals_out <- outdata$Month

global_pred_out <- predict(lmfit,data.frame(Month =timevals_out))

fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE

MAPE_class_dec <- accuracy(fcast,outdata[,2])[5]
MAPE_class_dec  # 24.51319

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred),ts(global_pred_out))
plot(total_timeser, col = "black")
lines(class_dec_pred, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

autoarima <- auto.arima(timeser)
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,outdata[,2])[5]
MAPE_auto_arima # 27.68952
# 
#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(total_timeser, col = "black")
lines(auto_arima_pred, col = "red")

#forecasting the sales for APAC for next 6 months
APAC_Sales_Next_6 <- forecast(auto_arima_pred, h=6)
APAC_Sales_Next_6
#plotting the forecast
plot(APAC_Sales_Next_6)

###################################################################################################3
# Let us now create TS for Quantity in APAC. 
APAC_DF_Quantity <- aggregate(APAC_Consumer$Quantity, by=list(Category=APAC_Consumer$order.YY.MM), FUN=sum)

# Add month number in the DF, which will be used for model prediction.
APAC_DF_Quantity$Month <- seq.int(nrow(APAC_DF_Quantity))
APAC_DF_Quantity <- subset(APAC_DF_Quantity,select=c(3,2))

colnames(APAC_DF_Quantity) <- c("Month","Quantity")

total_timeser <- ts(APAC_DF_Quantity$Quantity)
indata <- APAC_DF_Quantity[1:42,]
timeser <- ts(indata[,2])
plot(timeser)

# Let's first decompose the time series with a freq of 12, to see its components.
ts1 <-ts(indata[,2], frequency = 12)
decomposedRes <- decompose(ts1, type="mult") 
plot (decomposedRes) # As seen from the plots, we have trend as well as seasonality.

plot(timeser)

#Smoothing the series - Moving Average Smoothing
detach("package:dplyr",unload = TRUE)
w <-2
smoothedseries <- filter(timeser, 
                         filter=rep(1/(2*w+1),(2*w+1)), 
                         method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

#Plot the smoothed time series

timevals_in <- indata$Month
lines(smoothedseries, col="blue", lwd=2)

#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Quantity')

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit <- lm(Quantity ~ sin(0.55*Month) * poly(Month,3) + cos(0.55*Month) * poly(Month,3)
            + Month, data=smootheddf)
global_pred <- predict(lmfit, Month=timevals_in)
summary(global_pred)
lines(timevals_in, global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred <- timeser-global_pred
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

# ARIMA(0,0,0) with zero mean 
# 
# sigma^2 estimated as 10979:  log likelihood=-254.97
# AIC=511.95   AICc=512.05   BIC=513.69

#We'll check if the residual series is white noise

resi <- local_pred-fitted(armafit)
library(tseries)
adf.test(resi,alternative = "stationary")
kpss.test(resi)
# Both ADF and KPSS indicate that the residue is white noise. So we can stop here.

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months

outdata <- APAC_DF_Quantity[43:48,]
timevals_out <- outdata$Month

global_pred_out <- predict(lmfit,data.frame(Month =timevals_out))

fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE

MAPE_class_dec <- accuracy(fcast,outdata[,2])[5]
MAPE_class_dec #25.42832

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred),ts(global_pred_out))
plot(total_timeser, col = "black")
lines(class_dec_pred, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

autoarima <- auto.arima(timeser)
autoarima
# ARIMA(0,1,0 ) 
# 
# sigma^2 estimated as 25366:  log likelihood=-266.07
# AIC=534.14   AICc=534.24   BIC=535.85
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,outdata[,2])[5]
MAPE_auto_arima #26.24458
# 
#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(total_timeser, col = "black")
lines(auto_arima_pred, col = "red")

#forecating quantity for next 6 months.
APAC_Quant_forecast_6 <- forecast(auto.arima(auto_arima_pred),h=6)
APAC_Quant_forecast_6
#plotting the forecast
plot(APAC_Quant_forecast_6)

#####################################################################################################
# Let us now create TS for sales in EU.
EU_DF_Sales <- aggregate(EU_Consumer$Sales, by=list(Category=EU_Consumer$order.YY.MM), FUN=sum)

 
# Add month number in the DF, which will be used for model prediction.
EU_DF_Sales$Month <- seq.int(nrow(EU_DF_Sales))
EU_DF_Sales <- subset(EU_DF_Sales,select=c(3,2))

colnames(EU_DF_Sales) <- c("Month","Sales")

total_timeser <- ts(EU_DF_Sales$Sales)
indata <- EU_DF_Sales[1:42,]
timeser <- ts(indata[,2])
plot(timeser)


# Let's first decompose the time series with a freq of 12, to see its components.
ts1 <-ts(indata[,2], frequency = 12)
decomposedRes <- decompose(ts1, type="mult") 
plot (decomposedRes) # As seen from the plots, we have trend as well as seasonality.

plot(timeser)

#Smoothing the series - Moving Average Smoothing
detach("package:dplyr",unload = TRUE)
w <-2
smoothedseries <- filter(timeser, 
                         filter=rep(1/(2*w+1),(2*w+1)), 
                         method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

#Plot the smoothed time series

timevals_in <- indata$Month
lines(smoothedseries, col="blue", lwd=2)

#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Sales')

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit <- lm(Sales ~ sin(0.5555*Month) * poly(Month,3) + cos(0.5555*Month) * poly(Month,3)
            + Month, data=smootheddf)
global_pred <- predict(lmfit, Month=timevals_in)
summary(global_pred)
lines(timevals_in, global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred <- timeser-global_pred
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit
# ARIMA(0,0,0) with zero mean  
# 
# sigma^2 estimated as 9.8e+07:  log likelihood=-446
# AIC=894.01   AICc=894.11   BIC=895.75

#We'll check if the residual series is white noise

resi <- local_pred-fitted(armafit)
library(tseries)
adf.test(resi,alternative = "stationary")
kpss.test(resi)
#Both KPSS and ADF indicate that the residue is white noise.

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months

outdata <- EU_DF_Sales[43:48,]
timevals_out <- outdata$Month

global_pred_out <- predict(lmfit,data.frame(Month =timevals_out))

fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE

MAPE_class_dec <- accuracy(fcast,outdata[,2])[5]
MAPE_class_dec #24.52597

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred),ts(global_pred_out))
plot(total_timeser, col = "black")
lines(class_dec_pred, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

autoarima <- auto.arima(timeser)
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

# ARIMA(2,1,0) 
#
#   Coefficients:
#          ar1      ar2
#        -0.5796  -0.4906
#  s.e.   0.1346   0.1310

# sigma^2 estimated as 168564623:  log likelihood=-445.84
# AIC=897.67   AICc=898.32   BIC=902.81

#Again, let's check if the residual series is white noise

resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,outdata[,2])[5]
MAPE_auto_arima #28.9226
# 
#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(total_timeser, col = "black")
lines(auto_arima_pred, col = "red")

#forecating the next 6 months
EU_Sales_next_6 <- forecast(auto_arima_pred , h=6)
EU_Sales_next_6
# plotting the forecast
plot(EU_Sales_next_6)

####################################################################################################
# Let us now create TS for Quantity in EU. 
EU_DF_Quantity <- aggregate(EU_Consumer$Quantity, by=list(Category=EU_Consumer$order.YY.MM), FUN=sum)


# Add month number in the DF, which will be used for model prediction.
EU_DF_Quantity$Month <- seq.int(nrow(EU_DF_Quantity))
EU_DF_Quantity <- subset(EU_DF_Quantity,select=c(3,2))

colnames(EU_DF_Quantity) <- c("Month","Quantity")

total_timeser <- ts(EU_DF_Quantity$Quantity)
indata <- EU_DF_Quantity[1:42,]
timeser <- ts(indata[,2])
plot(timeser)

# Let's first decompose the time series with a freq of 12, to see its components.
ts1 <-ts(indata[,2], frequency = 12)
decomposedRes <- decompose(ts1, type="mult") 
plot (decomposedRes) # As seen from the plots, we have trend as well as seasonality.

plot(timeser)

#Smoothing the series - Moving Average Smoothing
detach("package:dplyr",unload = TRUE)
w <-2
smoothedseries <- filter(timeser, 
                         filter=rep(1/(2*w+1),(2*w+1)), 
                         method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

#Plot the smoothed time series

timevals_in <- indata$Month
lines(smoothedseries, col="blue", lwd=2)

#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('Month', 'Quantity')

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit <- lm(Quantity ~ sin(0.55*Month) * poly(Month,3) + cos(0.55*Month) * poly(Month,3)
            + Month, data=smootheddf)
global_pred <- predict(lmfit, Month=timevals_in)
summary(global_pred)
lines(timevals_in, global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred <- timeser-global_pred
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)

tsdiag(armafit)
armafit

# ARIMA(2,0,0) with zero mean 

# Coefficients:
#   ar1      ar2
# -0.5848  -0.5752
# s.e.   0.1244   0.1202
# 
# sigma^2 estimated as 8469:  log likelihood=-248.98
# AIC=503.95   AICc=504.58   BIC=509.16

#We'll check if the residual series is white noise

resi <- local_pred-fitted(armafit)
library(tseries)
adf.test(resi,alternative = "stationary")
kpss.test(resi)
# Both ADF and KPSS indicate that the residue is white noise.

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months

outdata <- EU_DF_Quantity[43:48,]
timevals_out <- outdata$Month

global_pred_out <- predict(lmfit,data.frame(Month =timevals_out))

fcast <- global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE

MAPE_class_dec <- accuracy(fcast,outdata[,2])[5]
MAPE_class_dec #27.16296

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred),ts(global_pred_out))
plot(total_timeser, col = "black")
lines(class_dec_pred, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

autoarima <- auto.arima(timeser)
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

# ARIMA(2,1,0) 
# 
# Coefficients:
#   ar1      ar2
# -0.7359  -0.5879
# s.e.   0.1224   0.1185
# 
# sigma^2 estimated as 21185:  log likelihood=-261.9
# AIC=529.8   AICc=530.44   BIC=534.94
#Again, let's check if the residual series is white noise

resi_auto_arima <- timeser - fitted(autoarima)

adf.test(resi_auto_arima,alternative = "stationary")
kpss.test(resi_auto_arima)

#Also, let's evaluate the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,outdata[,2])[5]
MAPE_auto_arima #30.13319
# 
#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(total_timeser, col = "black")
lines(auto_arima_pred, col = "red")

#forecasting the quanity for next 6 months
EU_Quantity_next_6 <- forecast(auto_arima_pred, h=6)
EU_Quantity_next_6

#plotting the forecast
plot(EU_Quantity_next_6)


################################################################################################

##Conclusions:
# Based on the data provided for Global mart, top 2 segments were identified to be 
#   #EU Consumer 
#   #APAC Consumer
# Models for sales and quantity were built for both the segments on 42 months of data keeping 6 months for evaluation of the model. The model fits well for data with the MAPE range within the acceptable region which is less than 30.
# Classical decomposition method has given slightly better than auto ARIMA modelling for both the segments.
# The sales and quantity of products is expected to grow over the next 6 months.
